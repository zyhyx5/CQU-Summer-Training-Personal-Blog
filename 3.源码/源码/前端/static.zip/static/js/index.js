var scn_data={
		map:[{area:"山东",cnt:20},
			{area:"浙江",cnt:400},
			{area:"江苏",cnt:500},
			{area:"辽宁",cnt:70}
		]
	};
var vm = new Vue({
	el: '#content',
	data: scn_data,
	methods: {
		details: function() {
			
		}
	}
})