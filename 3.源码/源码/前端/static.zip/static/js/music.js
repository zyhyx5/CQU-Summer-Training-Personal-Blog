const musicContainer = document.getElementById("music-container");
const playBtn = document.getElementById("play");
const prevBtn = document.getElementById("prev");
const nextBtn = document.getElementById("next");

const audio = document.getElementById("audio");
const progress = document.getElementById("progress");
const progressContainer = document.getElementById("progress-container");
const title = document.getElementById("title");
const musicCover = document.getElementById("music-cover");

// 音乐信息
const songs = ["打上花火", "Mojito", "Super_Star", "离人"];
// 默认从第一首开始
let songIndex = 0;

// 从 sessionStorage 中读取音乐盒状态
function loadMusicBoxState() {
  const state = JSON.parse(sessionStorage.getItem("musicBoxState"));
  if (state) {
    songIndex = state.songIndex;
    loadSong(songs[songIndex]);
    if (state.isPlaying) {
      playSong();
    } else {
      pauseSong();
    }
    audio.currentTime = state.currentTime;
    musicContainer.style.left = state.containerLeft;
    musicContainer.style.top = state.containerTop;
  } else {
    loadSong(songs[songIndex]);
  }
}

// 保存音乐盒状态到 sessionStorage
function saveMusicBoxState() {
  const state = {
    songIndex,
    isPlaying: musicContainer.classList.contains("play"),
    currentTime: audio.currentTime,
    containerLeft: musicContainer.style.left,
    containerTop: musicContainer.style.top,
  };
  sessionStorage.setItem("musicBoxState", JSON.stringify(state));
}

// 将歌曲细节加载到 DOM
function loadSong(song) {
  title.innerHTML = song;
  audio.src = `music/${song}.mp3`;
  musicCover.src = `img/${song}.jpg`;
}

// 播放歌曲
function playSong() {
  musicContainer.classList.add("play");
  playBtn.querySelector("i.fas").classList.remove("fa-play");
  playBtn.querySelector("i.fas").classList.add("fa-pause");

  audio.play();
}

// 停止播放
function pauseSong() {
  musicContainer.classList.remove("play");
  playBtn.querySelector("i.fas").classList.add("fa-play");
  playBtn.querySelector("i.fas").classList.remove("fa-pause");

  audio.pause();
}

// 上一首
function prevSong() {
  songIndex--;
  if (songIndex < 0) {
    songIndex = songs.length - 1;
  }
  loadSong(songs[songIndex]);
  playSong();
}

// 下一首
function nextSong() {
  songIndex++;
  if (songIndex > songs.length - 1) {
    songIndex = 0;
  }
  loadSong(songs[songIndex]);
  playSong();
}

// 进度条更新
function updateProgress(e) {
  const { duration, currentTime } = e.target;
  const progressPercent = (currentTime / duration) * 100;
  progress.style.width = `${progressPercent}%`;
}

// 设置进度条
function setProgress(e) {
  const width = this.clientWidth;
  const clickX = e.offsetX;
  const duration = audio.duration;
  audio.currentTime = (clickX / width) * duration;
}

// 事件监听
playBtn.onclick = function () {
  musicContainer.classList.contains("play") ? pauseSong() : playSong();
};

prevBtn.onclick = prevSong;
nextBtn.onclick = nextSong;

progressContainer.onclick = setProgress;

audio.ontimeupdate = updateProgress;

audio.onended = nextSong;

// 页面加载时恢复音乐盒状态
window.addEventListener("DOMContentLoaded", loadMusicBoxState);

// 页面关闭或刷新时保存音乐盒状态
window.addEventListener("beforeunload", saveMusicBoxState);

//实现拖动功能
let offsetX = 0;//鼠标坐标到元素的左侧的距离
let offsetY = 0;//鼠标坐标到元素的顶部的距离
let initialX = 0;//元素相对于视口左边缘的初始距离
let initialY = 0;//元素相对于视口上边缘的初始距离
let isDragging = false; // 拖动状态标志

// 鼠标按下事件
musicContainer.addEventListener("mousedown", startDrag);

// 鼠标释放事件
window.addEventListener("mouseup", stopDrag);

// 鼠标移动事件
window.addEventListener("mousemove", drag);

// 开始拖动
function startDrag(event) {
    //阻止默认的事件行为，以确保在拖动过程中不会发生意外的滚动或其他操作
  event.preventDefault();
  offsetX = event.clientX;//clientx:鼠标的坐标到页面左侧的距离
  offsetY = event.clientY;//clientY: 鼠标的坐标到页面顶部的距离
  const rect = musicContainer.getBoundingClientRect();
  initialX = rect.left;
  initialY = rect.top;
  // 添加类名以修改鼠标样式
  musicContainer.classList.add("dragging");
  // 设置拖动状态为true
  isDragging = true;
}

// 停止拖动
function stopDrag(event) {
  event.preventDefault();
  // 移除类名和拖动状态标志
  musicContainer.classList.remove("dragging");
  isDragging = false;
}

// 拖动
function drag(event) {
  event.preventDefault();
  // 检查拖动状态
  if (isDragging) {
    // 计算鼠标移动的距离
    const moveX = event.clientX - offsetX;
    const moveY = event.clientY - offsetY;
    // 更新音乐容器的位置
    musicContainer.style.left = initialX + moveX + "px";
    musicContainer.style.top = initialY + moveY + "px";
  }
}