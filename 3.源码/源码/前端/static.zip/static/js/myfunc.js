
//延时跳转
function delayURL(url, time) {
    setTimeout(function () {
        window.location.href = url;
    }, time);
}

//刷新页面
function refresh(time) {
    setTimeout(function () {
        location.reload();
    }, time);
}

//通过正则表达式验证用户名格式
function checkUsername(str){     
    //用户名格式：长度在2-20个字符之间，只能包含字母和数字
    var usernameGeshi = /^[a-zA-Z0-9]{2,20}$/
    return usernameGeshi.test(str)
}

//通过正则表达式验证邮箱格式
function checkMail(str){     
    var mailGeshi = /^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/
    return mailGeshi.test(str)
}

//通过正则表达式验证密码格式
function checkPassword(str){     
    //密码格式：长度在6-20个字符之间，必须包含字母和数字，且不能包含“?=.”之外的字符
    var passwordGeshi = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,20}$/
    return passwordGeshi.test(str)
}