package com.myblog.entity;

import lombok.Data;
import org.springframework.data.relational.core.sql.In;

@Data
public class ComWithBTitle {
    private long comId;
    private String username;
    private String nickname;
    private String head;
    private long blogId;
    private java.sql.Timestamp comTime;
    private String comContent;
    private String blogTitle;
    private Integer messageId;
}
