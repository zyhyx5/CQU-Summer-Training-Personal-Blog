package com.myblog.controller;


import com.myblog.entity.Result;
import com.myblog.entity.TypeLabelCount;
import com.myblog.entity.View;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin
public class DataController {

    @Autowired
    private JdbcTemplate jdbc;

    // 访客量加一
    @GetMapping("/visualViewAdd")
    public Result visualViewAdd() {
        Result res = new Result();
        try {
            jdbc.update("UPDATE `view` SET count = count + 1 WHERE `date` = CURDATE()");
            res.setCode(200);
            res.setResult("成功");
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了" + e.getMessage());
            return res;
        }
    }

    // 获取最近七天访问数据
    @GetMapping("/visualViewCount")
    public Result visualViewCount() {
        Result res = new Result();
        try {
            List<View> tmp=jdbc.query("SELECT `date`, `count`\n" +
                            "FROM `view`\n" +
                            "WHERE `date` BETWEEN DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND DATE_SUB(CURDATE(), INTERVAL 1 DAY);",
                    new BeanPropertyRowMapper<>(View.class));
            res.setCode(200);
            res.setResult(tmp);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了" + e.getMessage());
            return res;
        }
    }

    // 访问量总数
    @GetMapping("/visualViewSum")
    public Result visualViewSum(){
        Result res = new Result();
        try {
            Integer sum = jdbc.queryForObject("SELECT SUM(count) FROM view", Integer.class);
            res.setCode(200);
            res.setResult(sum);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了" + e.getMessage());
            return res;
        }
    }

    // 用户总数
    @GetMapping("/visualUserSum")
    public Result visualUserSum(){
        Result res = new Result();
        try {
            Integer sum = jdbc.queryForObject("SELECT count(username) FROM user", Integer.class);
            res.setCode(200);
            res.setResult(sum);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了" + e.getMessage());
            return res;
        }
    }

    // 用户性别
    @GetMapping("/visualSex")
    public Result visualSex(){
        Result res=new Result();
        try {
            List<TypeLabelCount> tmp=jdbc.query("select COUNT(username) as count,sex as TypeLabel\n" +
                            "from `user`\n" +
                            "GROUP BY sex order by sex",
                    new BeanPropertyRowMapper<>(TypeLabelCount.class));
            res.setCode(200);
            res.setResult(tmp);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了"+e.getMessage());
            return res;
        }
    }

    // 博客总数
    @GetMapping("/visualBlogSum")
    public Result visualBlogSum(){
        Result res = new Result();
        try {
            Integer sum = jdbc.queryForObject("SELECT count(blogId) FROM blog", Integer.class);
            res.setCode(200);
            res.setResult(sum);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了" + e.getMessage());
            return res;
        }
    }

    // 喜欢总数
    @GetMapping("/visualLikeSum")
    public Result visualLikeSum(){
        Result res = new Result();
        try {
            Integer sum = jdbc.queryForObject("SELECT SUM(numLike) FROM blog", Integer.class);
            res.setCode(200);
            res.setResult(sum);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了" + e.getMessage());
            return res;
        }
    }

    // 收藏总数
    @GetMapping("/visualStoreSum")
    public Result visualStoreSum(){
        Result res = new Result();
        try {
            Integer sum = jdbc.queryForObject("SELECT SUM(numStore) FROM blog", Integer.class);
            res.setCode(200);
            res.setResult(sum);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了" + e.getMessage());
            return res;
        }
    }

    // 分类和浏览量统计
    @GetMapping("/visualTypeView")
    public Result visualTypeView(){
        Result res=new Result();
        try {
            List<TypeLabelCount> tmp=jdbc.query("SELECT type as typeLabel,SUM(numVisit) as count\n" +
                            "from blog\n" +
                            "GROUP BY type\n" +
                            "ORDER BY type DESC",
                    new BeanPropertyRowMapper<>(TypeLabelCount.class));
            res.setCode(200);
            res.setResult(tmp);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了"+e.getMessage());
            return res;
        }
    }

    // 浏览量最高的文章排行
    @GetMapping("/visualBlogView")
    public Result visualBlogView(){
        Result res=new Result();
        try {
            List<TypeLabelCount> tmp=jdbc.query("SELECT blogTitle as typeLabel,numVisit as count\n" +
                            "from blog\n" +
                            "ORDER BY numVisit DESC\n" +
                            "LIMIT 6",
                    new BeanPropertyRowMapper<>(TypeLabelCount.class));
            res.setCode(200);
            res.setResult(tmp);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了"+e.getMessage());
            return res;
        }
    }

    // 省份
    @GetMapping("/visualProvince")
    public Result visualProvince(){
        Result res=new Result();
        try {
            List<TypeLabelCount> tmp=jdbc.query("SELECT province as typeLabel,COUNT(username) as count\n" +
                            "from `user`\n" +
                            "GROUP BY province",
                    new BeanPropertyRowMapper<>(TypeLabelCount.class));
            res.setCode(200);
            res.setResult(tmp);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了"+e.getMessage());
            return res;
        }
    }




}

