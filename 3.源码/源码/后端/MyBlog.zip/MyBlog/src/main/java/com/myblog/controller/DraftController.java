package com.myblog.controller;


import com.myblog.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController //说明是返回数据的httpApi接口(SpringMvc中叫做控制器)
@CrossOrigin //允许跨域
public class DraftController {

    @Autowired
    private JdbcTemplate jdbc;


    //新建草稿
    @PostMapping("/writeDraft")
    public Result writeDraft(@RequestBody Draft blog){
        Result res = new Result();
        try {
            jdbc.update("INSERT INTO draft(username,blogTitle,blogContent,type,flabel,slabel,numVisit,numLike,numStore,numComment,blogMd,blogTime,cover) VALUES(?,?,?,?,?,?,'0','0','0','0',?,?,?)" ,
                    blog.getUsername(),blog.getBlogTitle(),blog.getBlogContent(),blog.getType(),
                    blog.getFlabel(),blog.getSlabel(),blog.getBlogMd(),blog.getBlogTime(),blog.getCover()
            );
            res.setCode(200);
            res.setResult("成功创建草稿");
            return res;
        } catch (DataAccessException e) {
            e.printStackTrace();
            res.setCode(201);
            res.setResult("创建草稿失败"+e.getMessage());
            return res;
        }
    }


    //更新博客内容
    @PostMapping("/updateDraft")
    public Result updateDraft(@RequestBody Draft b){
        Result r = new Result();
        try {
            jdbc.update("UPDATE draft SET blogTitle=?,blogContent=?,type=?,flabel=?,slabel=?,blogMd=?,blogTime=?,cover=?  WHERE draftId = ?",
                    b.getBlogTitle(),b.getBlogContent(),b.getType(),b.getFlabel(),b.getSlabel(),b.getBlogMd(),b.getBlogTime(),b.getCover(),b.getDraftId());
            r.setCode(200);
            r.setResult("更新草稿成功");
        } catch (DataAccessException e) {
            r.setCode(201);
            r.setResult("更新草稿失败"+e.getMessage());
        }
        return r;
    }


    //按照时间顺序展示草稿
    @GetMapping("/ShowDraft")
    public Result ShowDraft(){
        Result res=new Result();
        try {
            List<DraftWithUser> blogs=jdbc.query("select * from draft order by blogTime DESC",
                    new BeanPropertyRowMapper<>(DraftWithUser.class));
            res.setCode(200);
            res.setResult(blogs);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了"+e.getMessage());
            return res;
        }
    }

    //删除
    @GetMapping("/deleteDraft")
    public Result deleteDraft(Integer id){
        Result r = new Result();
        try {
            jdbc.update("delete from draft WHERE draftId = ?",id);
            r.setCode(200);
            r.setResult("删除草稿成功");
        } catch (DataAccessException e) {
            r.setCode(201);
            r.setResult("删除草稿失败"+e.getMessage());
        }
        return r;
    }

    // 根据标题查询草稿
    @GetMapping("/queryDraftByTitle")
    public Result queryDraftByTitle(String l){
        Result res=new Result();
        try {
            List<Draft> blogs=null;
            if(l!=null){
                blogs=jdbc.query("select * from draft where blogTitle=?",
                        new BeanPropertyRowMapper<>(Draft.class),l);
            }else{
                blogs=jdbc.query("select * from draft",
                        new BeanPropertyRowMapper<>(Draft.class));
            }
            res.setCode(200);
            res.setResult(blogs);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了"+e.getMessage());
            return res;
        }

    }

    // 根据id查询草稿
    @GetMapping("/queryDraftById")
    public Result queryDraftById(Integer id){
        Result res = new Result();
        try {
            Draft b = jdbc.queryForObject("select * from draft where draftId=?",
                    new BeanPropertyRowMapper<>(Draft.class),id);
            res.setCode(200);
            res.setResult(b);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出现异常"+e.getMessage());//message 异常的信息
            return res;
        }
    }



}
