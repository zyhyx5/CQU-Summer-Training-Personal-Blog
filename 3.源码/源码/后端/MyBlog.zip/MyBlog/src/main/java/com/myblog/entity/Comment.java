package com.myblog.entity;


public class Comment {

  private long comId;
  private String username;
  private long blogId;
  private java.sql.Timestamp comTime;
  private String comContent;


  public long getComId() {
    return comId;
  }

  public void setComId(long comId) {
    this.comId = comId;
  }


  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }


  public long getBlogId() {
    return blogId;
  }

  public void setBlogId(long blogId) {
    this.blogId = blogId;
  }


  public java.sql.Timestamp getComTime() {
    return comTime;
  }

  public void setComTime(java.sql.Timestamp comTime) {
    this.comTime = comTime;
  }


  public String getComContent() {
    return comContent;
  }

  public void setComContent(String comContent) {
    this.comContent = comContent;
  }

}
