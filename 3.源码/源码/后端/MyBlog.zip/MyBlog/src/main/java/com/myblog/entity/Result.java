package com.myblog.entity;

import lombok.Data;

@Data
public class Result {
    public static Result ok(Integer pcode, Object presut){
        Result r = new Result();
        r.setCode(pcode);
        r.setResult(presut);
        return r;
    }
    private Integer code;  // 200-正常  201-异常
    private Object result;  //存真正的返回数据
}
