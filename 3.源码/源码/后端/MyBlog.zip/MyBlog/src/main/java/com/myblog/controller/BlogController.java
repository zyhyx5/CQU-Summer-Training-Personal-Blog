package com.myblog.controller;

import com.myblog.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@RestController //说明是返回数据的httpApi接口(SpringMvc中叫做控制器)
@CrossOrigin //允许跨域
public class BlogController {

    @Autowired
    private JdbcTemplate jdbc;

    //新建博客
    @PostMapping("/writeBlog")
    public Result writeBlog(@RequestBody Blog blog){

        Result res = new Result();
        try { //dateFormat.format(date)
            Date date = new Date();
            SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd :HH:mm:ss");
            jdbc.update("INSERT INTO blog(username,blogTitle,blogContent,type,flabel,slabel,numVisit,numLike,numStore,numComment,blogMd,blogTime,cover) VALUES(?,?,?,?,?,?,'0','0','0','0',?,?,?)" ,
                    blog.getUsername(),blog.getBlogTitle(),blog.getBlogContent(),blog.getType(),
                    blog.getFlabel(),blog.getSlabel(),blog.getBlogMd(),dateFormat.format(date),blog.getCover()
            );
            res.setCode(200);
            res.setResult("成功发布博客");
            return res;
        } catch (DataAccessException e) {
            e.printStackTrace();
            res.setCode(201);
            res.setResult("博客发布失败"+e.getMessage());
            return res;
        }

    }

    //更新博客内容
    @PostMapping("/updateBlog")
    public Result updateBlog(@RequestBody Blog b){
        Result r = new Result();
        try {
            jdbc.update("UPDATE blog SET blogTitle=?,blogContent=?,type=?,flabel=?,slabel=?,blogMd=?,cover=?  WHERE blogId = ?",
                    b.getBlogTitle(),b.getBlogContent(),b.getType(),b.getFlabel(),b.getSlabel(),b.getBlogMd(),b.getCover(),b.getBlogId());
            r.setCode(200);
            r.setResult("更新博客成功");
        } catch (DataAccessException e) {
            r.setCode(201);
            r.setResult("更新博客失败"+e.getMessage());
        }
        return r;
    }

    //博客删除
    @GetMapping("/deleteBlog")
    public Result deleteBlog(Integer id){
        Result r = new Result();
        try {
            jdbc.update("delete from blog WHERE blogId = ?",id);
            r.setCode(200);
            r.setResult("删除博客成功");
        } catch (DataAccessException e) {
            r.setCode(201);
            r.setResult("删除博客失败"+e.getMessage());
        }
        return r;
    }

    //博客查找
    //根据id查询博客（唯一）
    @GetMapping("/queryBlogById")
    public Result queryBlogById(Integer id){
        Result res = new Result();
        try {
            BlogWithUser b = jdbc.queryForObject("select blog.username,blogId,blogTitle,blogContent,blogMd,type," +
                            "flabel,slabel,numVisit,numLike,numStore,numComment,blogTime,cover,nickname,head " +
                            "from blog,`user` where blog.username=`user`.username and blogId=?",
                    new BeanPropertyRowMapper<>(BlogWithUser.class),id);
            res.setCode(200);
            res.setResult(b);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出现异常"+e.getMessage());//message 异常的信息
            return res;
        }
    }

    //根据标题查询  改为：根据标题或分类查询（部分符合）
    @GetMapping("/queryBlogByTitle")
    public Result queryBlogByTitle(String l){
        Result res=new Result();
        try {
            List<BlogWithUser> blogs=null;
            if(l!=null){
                blogs=jdbc.query("select blog.username,blogId,blogTitle,blogContent,blogMd,type,flabel,slabel," +
                                "numVisit,numLike,numStore,numComment,blogTime,cover,nickname,head from blog,`user` " +
                                "where blog.username=`user`.username and (blogTitle like concat('%',?,'%') or " +
                                "type like concat('%',?,'%'))",
                        new BeanPropertyRowMapper<>(BlogWithUser.class),l,l);
            }else{
                blogs=jdbc.query("select blog.username,blogId,blogTitle,blogContent,blogMd,type,flabel,slabel," +
                                "numVisit,numLike,numStore,numComment,blogTime,cover,nickname,head from blog,`user` where blog.username=`user`.username",
                        new BeanPropertyRowMapper<>(BlogWithUser.class));
            }
            res.setCode(200);
            res.setResult(blogs);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了"+e.getMessage());
            return res;
        }

    }

    //根据类别查询
    @GetMapping("/queryBlogByType")
    public Result queryBlogByType(String t){
        Result res=new Result();
        try {
            List<BlogWithUser> blogs=null;
            if(t!=null){
                blogs=jdbc.query("select blog.username,blogId,blogTitle,blogContent,blogMd,type,flabel,slabel," +
                                "numVisit,numLike,numStore,numComment,blogTime,cover,nickname,head from blog,`user` " +
                                "where blog.username=`user`.username and type=?",
                        new BeanPropertyRowMapper<>(BlogWithUser.class),t);
            }else{
                blogs=jdbc.query("select blog.username,blogId,blogTitle,blogContent,blogMd,type,flabel,slabel," +
                                "numVisit,numLike,numStore,numComment,blogTime,cover,nickname,head from blog,`user` " +
                                "where blog.username=`user`.username",
                        new BeanPropertyRowMapper<>(BlogWithUser.class));
            }
            res.setCode(200);
            res.setResult(blogs);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了"+e.getMessage());
            return res;
        }

    }

    //根据标签查询
    @GetMapping("/queryBlogByLabel")
    public Result queryBlogByLabel(String l){
        Result res=new Result();
        try {
            List<BlogWithUser> blogs=null;
            if(l!=null){
                blogs=jdbc.query("(select blog.username,blogId,blogTitle,blogContent,blogMd,type,flabel,slabel," +
                                "numVisit,numLike,numStore,numComment,blogTime,cover,nickname,head from blog,`user` " +
                                "where blog.username=`user`.username and flabel=?) union " +
                                "(select blog.username,blogId,blogTitle,blogContent,blogMd,type,flabel,slabel," +
                                "numVisit,numLike,numStore,numComment,blogTime,cover,nickname,head from blog,`user` " +
                                "where blog.username=`user`.username and slabel=?)",
                        new BeanPropertyRowMapper<>(BlogWithUser.class),l,l);
            }else{
                blogs=jdbc.query("select blog.username,blogId,blogTitle,blogContent,blogMd,type,flabel,slabel," +
                                "numVisit,numLike,numStore,numComment,blogTime,cover,nickname,head from blog,`user` " +
                                "where blog.username=`user`.username",
                        new BeanPropertyRowMapper<>(BlogWithUser.class));
            }
            res.setCode(200);
            res.setResult(blogs);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了"+e.getMessage());
            return res;
        }

    }

    //按照时间从近往前显示博客
    @GetMapping("/ShowByTime")
    public Result ShowByTime(){
        Result res=new Result();
        try {
            List<BlogWithUser> blogs=jdbc.query("select blog.username,blogId,blogTitle,blogContent,blogMd,type,flabel," +
                            "slabel,numVisit,numLike,numStore,numComment,blogTime,cover,nickname,head from blog,`user` " +
                            "where blog.username=`user`.username order by blogTime DESC",
                    new BeanPropertyRowMapper<>(BlogWithUser.class));
            res.setCode(200);
            res.setResult(blogs);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了"+e.getMessage());
            return res;
        }

    }


    //分类及对应的数量
    @GetMapping("/TypeNum")
    public Result TypeNum(){
        Result res=new Result();
        try {
            List<TypeLabelCount> tmp=jdbc.query("SELECT DISTINCT type as TypeLabel,COUNT(type) as count FROM blog " +
                            "group by type order by count DESC",
                    new BeanPropertyRowMapper<>(TypeLabelCount.class));
            res.setCode(200);
            res.setResult(tmp);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了"+e.getMessage());
            return res;
        }

    }

    //分类及对应的数量 限制5个
    @GetMapping("/TypeNumLimit")
    public Result TypeNumLimit(){
        Result res=new Result();
        try {
            List<TypeLabelCount> tmp=null;
            tmp=jdbc.query("SELECT DISTINCT type as TypeLabel,COUNT(type) as count FROM blog group by type ORDER BY count DESC limit 5",
                    new BeanPropertyRowMapper<>(TypeLabelCount.class));
            res.setCode(200);
            res.setResult(tmp);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了"+e.getMessage());
            return res;
        }
    }


    //标签及对应的数量
    @GetMapping("/LabelNum")
    public Result LabelNum(){
        Result res=new Result();
        try {
            List<TypeLabelCount> tmp=jdbc.query("SELECT ALL TypeLabel, COUNT(*) as count\n" +
                            "FROM (\n" +
                            "    SELECT slabel as TypeLabel FROM blog WHERE slabel IS NOT NULL and slabel!=''\n" +
                            "\t\tUNION ALL\n" +
                            "\t\tSELECT flabel FROM blog WHERE flabel IS NOT NULL and flabel!=''\n" +
                            ") subquery\n" +
                            "GROUP BY TypeLabel order by count DESC;\n",
                    new BeanPropertyRowMapper<>(TypeLabelCount.class));
            res.setCode(200);
            res.setResult(tmp);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了"+e.getMessage());
            return res;
        }

    }

    //标签及对应的数量 限制5个
    @GetMapping("/LabelNumLimit")
    public Result LabelNumLimit(){
        Result res=new Result();
        try {
            List<TypeLabelCount> tmp=null;
            tmp=jdbc.query("SELECT ALL TypeLabel, COUNT(*) as count\n" +
                            "FROM (\n" +
                            "    SELECT slabel as TypeLabel FROM blog WHERE slabel IS NOT NULL and slabel!=''\n" +
                            "\t\tUNION ALL\n" +
                            "\t\tSELECT flabel FROM blog WHERE flabel IS NOT NULL and flabel!=''\n" +
                            ") subquery\n" +
                            "GROUP BY TypeLabel ORDER BY count DESC limit 10",
                    new BeanPropertyRowMapper<>(TypeLabelCount.class));
            res.setCode(200);
            res.setResult(tmp);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了"+e.getMessage());
            return res;
        }

    }

    // 显示当前博客的评论
    @GetMapping("/showBlogComment")
    public Result showBlogComment(Integer bid){
        Result res = new Result();
        try {
            List<ComWithBTitle> com = jdbc.query("select nickname,head,comContent,comTime,comId,comment.username " +
                            "from comment,`user` where comment.username=`user`.username and blogId=?",
                    new BeanPropertyRowMapper<>(ComWithBTitle.class),bid);
            res.setCode(200);
            res.setResult(com);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出现异常"+e.getMessage());//message 异常的信息
            return res;
        }
    }

    // 点赞状态
    @GetMapping("/LikeOrNot")
    public Result LikeOrNot(Integer bid, String uname){
        Result res=new Result();
        try {
            jdbc.queryForObject("SELECT * from `like` where blogId=? and username=?",
                    new BeanPropertyRowMapper<>(Like.class),bid,uname);
            res.setCode(200);
            res.setResult("yes");
            return res;
        } catch (DataAccessException e) {
            res.setCode(200);
            res.setResult("no");
            return res;
        }
    }

    // 收藏状态
    @GetMapping("/StoreOrNot")
    public Result StoreOrNot(Integer bid, String uname){
        Result res=new Result();
        try {
            jdbc.queryForObject("SELECT * from `store` where blogId=? and username=?",
                    new BeanPropertyRowMapper<>(Store.class),bid,uname);
            res.setCode(200);
            res.setResult("yes");
            return res;
        } catch (DataAccessException e) {
            res.setCode(200);
            res.setResult("no");
            return res;
        }
    }


    // 按博客点赞数排序
    @GetMapping("/ShowByLiked")
    public Result ShowByLiked(){
        Result res=new Result();
        try {
            List<Blog> blogs=jdbc.query("select * from blog order by numLike DESC limit 5",
                    new BeanPropertyRowMapper<>(Blog.class));
            res.setCode(200);
            res.setResult(blogs);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了"+e.getMessage());
            return res;
        }
    }

    // 统计博客数目
    @GetMapping("/blogSum")
    public Result blogSum() {
        Result res = new Result();
        try {
            Integer sum = jdbc.queryForObject("SELECT COUNT(blogId) FROM blog", Integer.class);
            res.setCode(200);
            res.setResult(sum);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了" + e.getMessage());
            return res;
        }
    }

    // 浏览量
    @GetMapping("/blogViewNum")
    public Result blogViewNum(Integer canshu){
        Result r = new Result();
        try {
            jdbc.update("UPDATE blog SET numVisit = numVisit + 1 WHERE blogId=?",canshu);
            r.setCode(200);
            r.setResult("成功");
        } catch (DataAccessException e) {
            r.setCode(201);
            r.setResult("失败"+e.getMessage());
        }
        return r;
    }

    // 归档页
    @GetMapping("/blogYear")
    public Result blogYear(){
        Result res=new Result();
        try {
            List<YearBlog> yb = jdbc.query("SELECT Year, blogTitle,blogId,blogContent, cover, numVisit\n" +
                            "FROM (\n" +
                            "    SELECT\n" +
                            "        YEAR(blogTime) AS Year,\n" +
                            "        blogTitle,blogId,\n" +
                            "        blogContent,\n" +
                            "        cover,\n" +
                            "        numVisit,\n" +
                            "        @row_number := IF(@prev_year = YEAR(blogTime), @row_number + 1, 1) AS RowNum,\n" +
                            "        @prev_year := YEAR(blogTime)\n" +
                            "    FROM\n" +
                            "        blog, (SELECT @row_number := 0, @prev_year := NULL) AS vars\n" +
                            "    WHERE\n" +
                            "        YEAR(blogTime) BETWEEN 2017 AND 2023\n" +
                            "    ORDER BY\n" +
                            "        YEAR(blogTime) DESC, numVisit DESC\n" +
                            ") AS RankedBlogs\n" +
                            "WHERE RowNum = 1\n" +
                            "ORDER BY Year DESC",
                    new BeanPropertyRowMapper<>(YearBlog.class));
            res.setCode(200);
            res.setResult(yb);
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult(e.getMessage());
        }
        return res;
    }

}


