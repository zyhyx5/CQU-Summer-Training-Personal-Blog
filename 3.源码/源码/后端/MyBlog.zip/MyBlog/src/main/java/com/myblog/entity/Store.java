package com.myblog.entity;


public class Store {

  private long storeId;
  private String username;
  private long blogId;
  private java.sql.Timestamp storeTime;


  public long getStoreId() {
    return storeId;
  }

  public void setStoreId(long storeId) {
    this.storeId = storeId;
  }


  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }


  public long getBlogId() {
    return blogId;
  }

  public void setBlogId(long blogId) {
    this.blogId = blogId;
  }


  public java.sql.Timestamp getStoreTime() {
    return storeTime;
  }

  public void setStoreTime(java.sql.Timestamp storeTime) {
    this.storeTime = storeTime;
  }

}
