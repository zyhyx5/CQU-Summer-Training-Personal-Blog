package com.myblog.entity;

import lombok.Data;

@Data
public class TypeLabelCount {
    private String TypeLabel;
    private long count;
}

