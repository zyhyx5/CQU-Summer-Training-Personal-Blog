package com.myblog.controller;

import com.myblog.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController //说明是返回数据的httpApi接口(SpringMvc中叫做控制器)
@CrossOrigin //允许跨域
public class MessageController {

    @Autowired
    private JdbcTemplate jdbc;

    //查看赞赏信息
    @GetMapping("/MessageLike")
    public Result MessageLike(){
        Result res = new Result();
        try {
            String sql="SELECT * from `like` WHERE likeId IN (select queryId as likeId from message where messageType='L')";
            List<Like> likes=jdbc.query(sql,new BeanPropertyRowMapper<>(Like.class));
            res.setCode(200);
            res.setResult(likes);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了"+e.getMessage());
            return res;
        }

    }

    //查看收藏信息
    @GetMapping("/MessageStore")
    public Result MessageStore(){
        Result res = new Result();
        try {
            String sql="SELECT * from `store` WHERE storeId IN (select queryId as storeId from message where messageType='S')";
            List<Store> stores=jdbc.query(sql,new BeanPropertyRowMapper<>(Store.class));
            res.setCode(200);
            res.setResult(stores);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了"+e.getMessage());
            return res;
        }

    }

    //查看评论信息
    @GetMapping("/MessageComment")
    public Result MessageComment(){
        Result res = new Result();
        try {
            String sql="SELECT `comment`.comId, `comment`.username, `comment`.blogId,`comment`.comTime,`comment`.comContent,blog.blogTitle\n" +
                    "FROM (SELECT queryId AS comId FROM message WHERE messageType = 'C') AS subquery\n" +
                    "JOIN comment ON comment.comId = subquery.comId\n" +
                    "JOIN blog ON comment.blogId = blog.blogId order by comTime DESC ";
            List<ComWithBTitle> tmp=jdbc.query(sql,new BeanPropertyRowMapper<>(ComWithBTitle.class));
            res.setCode(200);
            res.setResult(tmp);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了"+e.getMessage());
            return res;
        }

    }

    //查询评论
    @GetMapping("/SearchMessage")
    public Result SearchMessage(String canshu){
        Result res = new Result();
        try {
            String sql="SELECT `comment`.comId, `comment`.username, `comment`.blogId,`comment`.comTime,`comment`.comContent,blog.blogTitle\n" +
                    "FROM (SELECT queryId AS comId FROM message WHERE messageType = 'C') AS subquery\n" +
                    "JOIN comment ON comment.comId = subquery.comId\n" +
                    "JOIN blog ON comment.blogId = blog.blogId\n" +
                    "where blog.blogTitle=?";
            List<ComWithBTitle> tmp=jdbc.query(sql,new BeanPropertyRowMapper<>(ComWithBTitle.class),canshu);
            res.setCode(200);
            res.setResult(tmp);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了"+e.getMessage());
            return res;
        }

    }


    //删除消息
    @GetMapping("/deleteMessage")
    public Result deleteMessage(Integer id){
        // 传入的id参数是comId
        Result r = new Result();
        try {
            jdbc.update("delete from message WHERE messageType='C' and queryId = ?",id);
            r.setCode(200);
            r.setResult("删除消息成功");
        } catch (DataAccessException e) {
            r.setCode(201);
            r.setResult("删除消息失败"+e.getMessage());
        }
        return r;
    }

}
