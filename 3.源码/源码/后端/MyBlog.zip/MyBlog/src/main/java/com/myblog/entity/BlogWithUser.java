package com.myblog.entity;

import lombok.Data;

@Data
public class BlogWithUser {
    private long blogId;
    private String username;
    private String blogTitle;
    private String blogContent;
    private String blogMd;
    private String type;
    private String flabel;
    private String slabel;
    private long numVisit;
    private long numLike;
    private long numStore;
    private long numComment;
    private java.sql.Timestamp blogTime;
    private String cover;

    private String nickname;
//    private String mail;
//    private String sex;
//    private long age;
//    private String password;
//    private String province;
//    private long level;
    private String head;

}


