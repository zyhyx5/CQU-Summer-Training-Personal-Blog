package com.myblog.entity;


public class Like {

  private long likeId;
  private String username;
  private long blogId;
  private java.sql.Timestamp likeTime;


  public long getLikeId() {
    return likeId;
  }

  public void setLikeId(long likeId) {
    this.likeId = likeId;
  }


  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }


  public long getBlogId() {
    return blogId;
  }

  public void setBlogId(long blogId) {
    this.blogId = blogId;
  }


  public java.sql.Timestamp getLikeTime() {
    return likeTime;
  }

  public void setLikeTime(java.sql.Timestamp likeTime) {
    this.likeTime = likeTime;
  }

}
