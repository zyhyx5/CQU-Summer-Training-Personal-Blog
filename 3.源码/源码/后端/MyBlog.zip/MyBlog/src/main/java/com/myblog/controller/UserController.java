package com.myblog.controller;

import com.myblog.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@RestController  //这里所有请求返回的是数据
@CrossOrigin(origins = "*")  //允许跨域
public class UserController {
    @Autowired
    private JdbcTemplate jdbc;



    //注册
    @PostMapping("/doRegister")
    //http://192.168.1.192:8088/doRegister
    public Result doRegister(@RequestBody User user){
        Result res = new Result();
        try {
            jdbc.update("insert into `user`(username,nickname,mail,sex,age,`password`,province,head) values(?,?,?,?,?,?,?,?)",
                    user.getUsername(),user.getNickname(),user.getMail(),user.getSex(),user.getAge(),
                    user.getPassword(),user.getProvince(),user.getHead());
            res.setCode(200);
            res.setResult("注册成功");
        } catch (DataAccessException e) {
            e.printStackTrace();
            res.setCode(201);
            res.setResult("注册失败 "+e.getMessage());  //用户名已存在 or 信息不完整
        }
        return res;
    }

    //登录
    @PostMapping("/doLogin")
    //http://192.168.1.192:8088/doLogin
    public Result doLogin(@RequestBody User user){
        System.out.println(user.getUsername()+"\t"+user.getPassword());
        Result res = new Result();
        try {
            User u = jdbc.queryForObject("select * from `user` where username=? and `password`=?",
                    new BeanPropertyRowMapper<>(User.class), user.getUsername(), user.getPassword());
            res.setCode(200);
            res.setResult(u);  //用户数据放入结果中
        } catch (DataAccessException e) {
            e.printStackTrace();
            res.setCode(201);
            res.setResult("登录失败");  //用户名或密码错误
        }
        return res;
    }


    // 查询用户是否存在
    @GetMapping("/userExist")
    public Result userExist(String username){
        Result res=new Result();
        try {
            jdbc.queryForObject("select * from `user` where username=?",
                    new BeanPropertyRowMapper<>(User.class), username);
            res.setCode(200);
            res.setResult("yes");
            return res;
        } catch (DataAccessException e) {
            res.setCode(200);
            res.setResult("no");
            return res;
        }
    }


    //忘记密码
    //邮箱验证
    @PostMapping("/forgetPassword/checkMail")
    //http://192.168.1.192:8088/forgetPassword/checkMail
    public Result checkMail(@RequestBody User user){
        System.out.println(user.getUsername()+"\t"+user.getMail());
        Result res = new Result();
        try {
            User u = jdbc.queryForObject("select * from `user` where username=? and `mail`=?",
                    new BeanPropertyRowMapper<>(User.class), user.getUsername(), user.getMail());
            res.setCode(200);
            res.setResult(u);  //用户数据放入结果中
        } catch (DataAccessException e) {
            e.printStackTrace();
            res.setCode(201);
            res.setResult("邮箱验证失败");
        }
        return res;
    }

    //修改密码
    @PostMapping("/forgetPassword/updatePassword")
    //http://192.168.1.192:8088/forgetPassword/updatePassword
    public Result updatePassword(@RequestBody User user){
        Result r = new Result();
        try {
            jdbc.update("update `user` set `password`=? where username=?",
                    user.getPassword(), user.getUsername());
            r.setCode(200);
            r.setResult("修改成功");
        } catch (DataAccessException e) {
            r.setCode(201);
            r.setResult("修改失败");
        }
        return r;
    }


    //修改个人信息
    @PostMapping("/updateUser")
    //http://192.168.1.192:8088/updateUser
    public Result updateUser(@RequestBody User user){
        Result r = new Result();
        try {
            jdbc.update("update `user` set nickname=?, mail=?, sex=?, age=?, `password`=?, province=?, " +
                            "head=? where username=?",
                    user.getNickname(), user.getMail(), user.getSex(), user.getAge(), user.getPassword(),
                    user.getProvince(), user.getHead(), user.getUsername());
            User u = jdbc.queryForObject("select * from `user` where username=?",
                    new BeanPropertyRowMapper<>(User.class), user.getUsername());
            r.setCode(200);
            r.setResult(u);
        } catch (DataAccessException e) {
            r.setCode(201);
            r.setResult("修改失败");
        }
        return r;
    }



    //查询用户 根据用户名或昵称 可部分符合
    @GetMapping("/searchUser")
    //http://192.168.1.192:8088/searchUser
    public Result searchUser(String s){
        Result res=new Result();
        try {
            List<User> users=null;
            if(s!=null){
                users=jdbc.query("select * from `user` where username like concat('%',?,'%') or " +
                                "nickname like concat('%',?,'%')",
                        new BeanPropertyRowMapper<>(User.class),s,s);
            }else{
                users=jdbc.query("select * from blog",
                        new BeanPropertyRowMapper<>(User.class));
            }
            res.setCode(200);
            res.setResult(users);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了"+e.getMessage());
            return res;
        }
    }


    //删除用户
    @PostMapping("/delUser")
    //http://192.168.1.192:8088/delUser
    public Result delUser(@RequestBody User user){
        Result res = new Result();
        try {
            jdbc.update("delete from `user` where username = ?", user.getUsername());
            res.setCode(200);
            res.setResult("删除用户成功");
        } catch (DataAccessException e) {
            e.printStackTrace();
            res.setCode(201);
            res.setResult("删除用户失败");
        }
        return res;
    }



    //评论
    @PostMapping("/doComment")
    //http://192.168.1.192:8088/doComment
    public Result doComment(@RequestBody Comment comment){
        Result res = new Result();
        try {
            Date date = new Date();
            SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd :HH:mm:ss");
            String time = dateFormat.format(date);
            jdbc.update("insert into `comment`(username,blogId,comTime,comContent) values(?,?,?,?)",
                    comment.getUsername(),comment.getBlogId(), time,comment.getComContent());
            jdbc.update("update blog set numComment=numComment+1 where blogId=?",
                    comment.getBlogId());
            long comId = jdbc.queryForObject("select comId from `comment` where username=? and comTime=?",
                    long.class, comment.getUsername(), time);
            jdbc.update("insert into message(queryId,messageType) values(?,'C')", comId);
            res.setCode(200);
            res.setResult("评论成功");
        } catch (DataAccessException e) {
            e.printStackTrace();
            res.setCode(201);
            res.setResult("评论失败");
        }
        return res;
    }

    //删除评论
    @PostMapping("/delComment")
    //http://192.168.1.192:8088/delComment
    public Result delComment(@RequestBody Comment comment){
        Result res = new Result();
        try {
            jdbc.update("delete from `comment` where comId = ?", comment.getComId());
            jdbc.update("update blog set numComment=numComment-1 where blogId=?", comment.getBlogId());
            jdbc.update("delete from message where messageType='C' and queryId=?", comment.getComId());
            res.setCode(200);
            res.setResult("删除评论成功");
        } catch (DataAccessException e) {
            e.printStackTrace();
            res.setCode(201);
            res.setResult("删除评论失败");
        }
        return res;
    }



    //点赞
    @PostMapping("/doLike")
    //http://192.168.1.192:8088/doLike
    public Result doComment(@RequestBody Like like){
        Result res = new Result();
        try {
            Date date = new Date();
            SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd :HH:mm:ss");
            jdbc.update("insert into `like`(username,blogId,likeTime) values(?,?,?)",
                    like.getUsername(),like.getBlogId(),dateFormat.format(date));
            jdbc.update("update blog set numLike=numLike+1 where blogId=?",
                    like.getBlogId());
            long likeId = jdbc.queryForObject("select likeId from `like` where username=? and blogId=?",
                    long.class, like.getUsername(), like.getBlogId());
            jdbc.update("insert into message(queryId,messageType) values(?,'L')", likeId);
            res.setCode(200);
            res.setResult("点赞成功");
        } catch (DataAccessException e) {
            e.printStackTrace();
            res.setCode(201);
            res.setResult("点赞失败");
        }
        return res;
    }

    //取消点赞
    @PostMapping("/delLike")
    //http://192.168.1.192:8088/delLike
    public Result delLike(@RequestBody Like like){
        Result res = new Result();
        try {
            //System.out.println(like.getUsername()+"   "+like.getBlogId());
            jdbc.update("delete from `like` where username=? and blogId=?", like.getUsername(), like.getBlogId());
            jdbc.update("update blog set numLike=numLike-1 where blogId=?", like.getBlogId());
            jdbc.update("delete from message where messageType='L' and queryId=?", like.getLikeId());
            res.setCode(200);
            res.setResult("取消点赞成功");
        } catch (DataAccessException e) {
            e.printStackTrace();
            res.setCode(201);
            res.setResult("取消点赞失败");
        }
        return res;
    }



    //收藏
    @PostMapping("/doStore")
    //http://192.168.1.192:8088/doStore
    public Result doStore(@RequestBody Store store){
        Result res = new Result();
        try {
            Date date = new Date();
            SimpleDateFormat dateFormat= new SimpleDateFormat("yyyy-MM-dd :HH:mm:ss");
            jdbc.update("insert into store(username,blogId,storeTime) values(?,?,?)",
                    store.getUsername(),store.getBlogId(),dateFormat.format(date));
            jdbc.update("update blog set numStore=numStore+1 where blogId=?",
                    store.getBlogId());
            long storeId = jdbc.queryForObject("select storeId from store where username=? and blogId=?",
                    long.class, store.getUsername(), store.getBlogId());
            jdbc.update("insert into message(queryId,messageType) values(?,'S')", storeId);
            res.setCode(200);
            res.setResult("收藏成功");
        } catch (DataAccessException e) {
            e.printStackTrace();
            res.setCode(201);
            res.setResult("收藏失败");
        }
        return res;
    }

    //取消收藏
    @PostMapping("/delStore")
    //http://192.168.1.192:8088/delStore
    public Result delStore(@RequestBody Store store){
        Result res = new Result();
        try {
            jdbc.update("delete from store where username=? and blogId=?", store.getUsername(), store.getBlogId());
            jdbc.update("update blog set numStore=numStore-1 where blogId=?", store.getBlogId());
            jdbc.update("delete from message where messageType='S' and queryId=?", store.getStoreId());
            res.setCode(200);
            res.setResult("取消收藏成功");
        } catch (DataAccessException e) {
            e.printStackTrace();
            res.setCode(201);
            res.setResult("取消收藏失败");
        }
        return res;
    }

    //查看指定分类的收藏列表
    @GetMapping("/queryStore")
    //http://192.168.1.192:8088/queryStore?username=zhangsan&type=学习
    public Result queryStore(String username, String type){
        Result res = new Result();
        try {
            List<BlogWithUser> blogs=jdbc.query("select blog.username,blogId,blogTitle,blogContent,blogMd,`type`,flabel," +
                    "slabel,numVisit,numLike,numStore,numComment,blogTime,cover,nickname,head from blog,`user` " +
                    "where blog.username=`user`.username and blogId in (select blogId from store where username=?) " +
                    "and type=?", new BeanPropertyRowMapper<>(BlogWithUser.class), username, type);
            res.setCode(200);
            res.setResult(blogs);
        } catch (DataAccessException e) {
            e.printStackTrace();
            res.setCode(201);
            res.setResult("查询失败");
        }
        return res;
    }

    //收藏博客的分类及对应的数量
    @GetMapping("/storeTypeNum")
    //http://192.168.1.192:8088/storeTypeNum?username=zhangsan
    public Result storeTypeNum(String username){
        Result res=new Result();
        try {
            List<TypeLabelCount> tmp=jdbc.query("select distinct type as TypeLabel,count(type) as count from store " +
                            "join blog where store.username=? and store.blogId=blog.blogId group by type order by count DESC",
                    new BeanPropertyRowMapper<>(TypeLabelCount.class), username);
            res.setCode(200);
            res.setResult(tmp);
            return res;
        } catch (DataAccessException e) {
            res.setCode(201);
            res.setResult("出错了"+e.getMessage());
            return res;
        }

    }
}
