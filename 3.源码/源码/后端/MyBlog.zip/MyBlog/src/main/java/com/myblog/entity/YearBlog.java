package com.myblog.entity;

import lombok.Data;

@Data
public class YearBlog {
    private Integer year;
    private String blogTitle;
    private String blogContent;
    private String cover;
    private Integer numVisit;
    private Integer blogId;
}
