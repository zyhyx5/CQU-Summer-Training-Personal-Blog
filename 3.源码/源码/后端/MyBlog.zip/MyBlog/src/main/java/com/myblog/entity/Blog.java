package com.myblog.entity;


public class Blog {

  private long blogId;
  private String username;
  private String blogTitle;
  private String blogContent;
  private String blogMd;
  private String type;
  private String flabel;
  private String slabel;
  private long numVisit;
  private long numLike;
  private long numStore;
  private long numComment;
  private java.sql.Timestamp blogTime;
  private String cover;


  public long getBlogId() {
    return blogId;
  }

  public void setBlogId(long blogId) {
    this.blogId = blogId;
  }


  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }


  public String getBlogTitle() {
    return blogTitle;
  }

  public void setBlogTitle(String blogTitle) {
    this.blogTitle = blogTitle;
  }


  public String getBlogContent() {
    return blogContent;
  }

  public void setBlogContent(String blogContent) {
    this.blogContent = blogContent;
  }


  public String getBlogMd() {
    return blogMd;
  }

  public void setBlogMd(String blogMd) {
    this.blogMd = blogMd;
  }


  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }


  public String getFlabel() {
    return flabel;
  }

  public void setFlabel(String flabel) {
    this.flabel = flabel;
  }


  public String getSlabel() {
    return slabel;
  }

  public void setSlabel(String slabel) {
    this.slabel = slabel;
  }


  public long getNumVisit() {
    return numVisit;
  }

  public void setNumVisit(long numVisit) {
    this.numVisit = numVisit;
  }


  public long getNumLike() {
    return numLike;
  }

  public void setNumLike(long numLike) {
    this.numLike = numLike;
  }


  public long getNumStore() {
    return numStore;
  }

  public void setNumStore(long numStore) {
    this.numStore = numStore;
  }


  public long getNumComment() {
    return numComment;
  }

  public void setNumComment(long numComment) {
    this.numComment = numComment;
  }


  public java.sql.Timestamp getBlogTime() {
    return blogTime;
  }

  public void setBlogTime(java.sql.Timestamp blogTime) {
    this.blogTime = blogTime;
  }


  public String getCover() {
    return cover;
  }

  public void setCover(String cover) {
    this.cover = cover;
  }

}
