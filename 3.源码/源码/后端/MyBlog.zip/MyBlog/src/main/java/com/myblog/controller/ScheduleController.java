package com.myblog.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.dao.DataAccessException;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.jdbc.core.JdbcTemplate;

@SpringBootApplication
@EnableScheduling
public class ScheduleController {

    @Autowired
    private JdbcTemplate jdbc;

    @Scheduled(fixedDelay = 5000)
    @Transactional
    public void moveDraft(){
        try {
            jdbc.update("INSERT INTO blog (\n" +
                    "username,blogTitle,blogContent,type,flabel,slabel,numVisit,numLike,numStore,numComment,blogMd,blogTime,cover)\n" +
                    "SELECT \n" +
                    "username,blogTitle,blogContent,type,flabel,slabel,numVisit,numLike,numStore,numComment,blogMd,blogTime,cover\n" +
                    "FROM draft\n" +
                    "WHERE blogTime < NOW();");
            jdbc.update("DELETE FROM draft WHERE blogTime < NOW()");
        } catch (DataAccessException e) {
            e.printStackTrace();
        }
    }

    @Scheduled(cron = "0 0 0 * * ?") // 每天00:00执行
    public void executeAtMidnight() {
        try {
            jdbc.update("INSERT into `view`(date,count) values(NOW(),0)");
        } catch (DataAccessException e) {
            e.printStackTrace();
        }
    }

}


