package com.upload.controller;

import com.upload.entity.Result;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

@CrossOrigin
@RestController
public class UploadController {
    @PostMapping("/upload")
    public Result doUpload(MultipartFile file){
        String fname = file.getOriginalFilename();
        int pos = fname.lastIndexOf(".");
        String houzhui = fname.substring(pos);
        String newFilename = UUID.randomUUID()+houzhui;
        try {
            file.transferTo(new File("d:/upload/images/"+newFilename));
            return Result.ok(200,"http://localhost/images/"+newFilename);
        } catch (IOException e) {
            e.printStackTrace();
            return Result.ok(201,"上传失败");
        }
    }
}

//import com.upload.entity.Result;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.multipart.MultipartFile;
//
//import java.io.File;
//import java.io.IOException;
//import java.util.UUID;
//
//@CrossOrigin
//@RestController
//public class UploadController {
//
//    @Value("${picserver.rootpath}")
//    private String host;
//    @PostMapping("/upload")
//    public Result doUpload(MultipartFile file){//file就能接收 请求参数名为  file 的文件
//
//        String fname = file.getOriginalFilename(); //得到上传的文件的文件名
//        int pos = fname.lastIndexOf("."); //得到 .所在的位置
//        String houZhui = fname.substring(pos);//截取从pos这个位置开始 到结束的字符串  其实就是得到后缀名
//        String newFileName = UUID.randomUUID()+houZhui;
//        try {
//            //以新的文件名 上传到 d:/upload/images/
//            file.transferTo(new File("d:/upload/images/"+newFileName));
//            //返回上传成功后  图片的完整路径，以供前台保存图片路径用
//            return Result.ok(200,host+"images/"+newFileName);
//        } catch (IOException e) {
//            e.printStackTrace();
//            return Result.ok(201,"上传失败");
//        }
//    }
//}
