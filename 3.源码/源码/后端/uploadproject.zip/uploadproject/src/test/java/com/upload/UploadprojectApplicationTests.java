package com.upload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UploadprojectApplicationTests {

    @Test
    void contextLoads() {
    }

}
